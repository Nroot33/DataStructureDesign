
public class Graph {
	private int size;
	private String[] vertices; // ���ڿ� Ÿ���� �迭 ����
	private Node[] a; // ��� Ÿ�� �迭 ����

	class Node { // ��� Ŭ���� 
		int data;
		Node next;

		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
	} 

	public int index(String a) { // �ε��� ��ȯ �޼ҵ�
		for (int i = 0; i < size; i++) {
			if (vertices[i].equals(a))
				return i;
		}
		return size;
	}

	public Graph(String[] parameter) { // �׷��� ���� 
		vertices = new String[size = parameter.length];
		System.arraycopy(parameter, 0, vertices, 0, size);
		a = new Node[size];
		for (int i = 0; i < size; i++)
			a[i] = new Node(index(vertices[i]), null);
	}

	public void add(String n, String m) { // ��� ���� �޼ҵ�
		a[index(n)].next = new Node(index(m), a[index(n)].next);
		a[index(m)].next = new Node(index(n), a[index(m)].next);
	}

	public String vertex(int i) { // vertex ��ȯ �޼ҵ�
		StringBuffer buf = new StringBuffer(vertices[i] + " : ");
		for (Node p = a[i].next; p!= null; p = p.next)
			buf.append(vertices[p.data]);
		return buf + " ";
	}

	public String toString() { // toString �޼ҵ�
		if (size == 0)
			return "{ }";
		StringBuffer buf = new StringBuffer("{" + vertex(0));
		for (int i = 1; i < size; i++)
			buf.append(", " + vertex(i));
		return buf + " }";
	}

	public void findPath(String v, String w) { // ��� ã�� �޼ҵ�
		int i = index(v), j = index(w);
		for (Node p = a[i]; p.next != null; p = p.next)
			for (Node q = a[p.next.data]; q.next != null; q = q.next) {
				if (p.next.data == j)
					continue;
				if (q.data == j) {
					System.out.println(v + " -> " + w + " : " + v + " - " + vertices[p.next.data] + " - " + w);
				}
			}
	}
}